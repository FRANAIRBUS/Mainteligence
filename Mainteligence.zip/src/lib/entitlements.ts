import { doc, getDoc, type Firestore } from "firebase/firestore";
import type {
  Entitlement,
  EntitlementFeature,
  EntitlementLimits,
  EntitlementUsage,
  Organization,
  PlanCatalogEntry,
} from "@/lib/firebase/models";

const DEFAULT_PLAN_FEATURES: Record<
  Entitlement["planId"],
  Record<EntitlementFeature, boolean>
> = {
  free: {
    EXPORT_PDF: false,
    AUDIT_TRAIL: false,
    PREVENTIVES: false,
  },
  basic: {
    EXPORT_PDF: false,
    AUDIT_TRAIL: false,
    PREVENTIVES: false,
  },
  starter: {
    EXPORT_PDF: true,
    AUDIT_TRAIL: false,
    PREVENTIVES: true,
  },
  pro: {
    EXPORT_PDF: true,
    AUDIT_TRAIL: true,
    PREVENTIVES: true,
  },
  enterprise: {
    EXPORT_PDF: true,
    AUDIT_TRAIL: true,
    PREVENTIVES: true,
  },
};

const DEFAULT_PLAN_LIMITS: Record<Entitlement["planId"], EntitlementLimits> = {
  free: {
    maxUsers: 2,
    maxSites: 1,
    maxDepartments: 3,
    maxAssets: 1,
    maxActivePreventives: 0,
    maxOpenTickets: 10,
    maxOpenTasks: 10,
    attachmentsMonthlyMB: 0,
    maxAttachmentMB: 0,
    maxAttachmentsPerTicket: 0,
    retentionDays: 0,
  },
  basic: {
    maxUsers: 5,
    maxSites: 2,
    maxDepartments: 5,
    maxAssets: 5,
    maxActivePreventives: 0,
    maxOpenTickets: 50,
    maxOpenTasks: 50,
    attachmentsMonthlyMB: 0,
    maxAttachmentMB: 0,
    maxAttachmentsPerTicket: 0,
    retentionDays: 0,
  },
  starter: {
    maxUsers: 10,
    maxSites: 5,
    maxDepartments: 15,
    maxAssets: 200,
    maxActivePreventives: 50,
    maxOpenTickets: 200,
    maxOpenTasks: 200,
    attachmentsMonthlyMB: 500,
    maxAttachmentMB: 10,
    maxAttachmentsPerTicket: 10,
    retentionDays: 180,
  },
  pro: {
    maxUsers: 25,
    maxSites: 15,
    maxDepartments: 50,
    maxAssets: 1000,
    maxActivePreventives: 250,
    maxOpenTickets: 1000,
    maxOpenTasks: 1000,
    attachmentsMonthlyMB: 5000,
    maxAttachmentMB: 25,
    maxAttachmentsPerTicket: 25,
    retentionDays: 365,
  },
  enterprise: {
    maxUsers: 10_000,
    maxSites: 10_000,
    maxDepartments: 10_000,
    maxAssets: 1_000_000,
    maxActivePreventives: 100_000,
    maxOpenTickets: 1_000_000,
    maxOpenTasks: 1_000_000,
    attachmentsMonthlyMB: 100_000,
    maxAttachmentMB: 100,
    maxAttachmentsPerTicket: 100,
    retentionDays: 3650,
  },
};

const resolvePlanAlias = (planId: string): Entitlement["planId"] | null => {
  if (planId.startsWith("free")) return "free";
  if (planId.startsWith("basic")) return "basic";
  if (planId.startsWith("standard")) return "starter";
  if (planId.startsWith("starter")) return "starter";
  if (planId.startsWith("pro")) return "pro";
  if (planId.startsWith("enterprise")) return "enterprise";
  return null;
};

export const normalizePlanId = (
  planId?: Entitlement["planId"] | string
): Entitlement["planId"] => {
  const normalized = String(planId ?? "").trim().toLowerCase();
  if (normalized in DEFAULT_PLAN_LIMITS) {
    return normalized as Entitlement["planId"];
  }
  return resolvePlanAlias(normalized) ?? "free";
};

export const getDefaultPlanFeatures = (
  planId?: Entitlement["planId"] | string
): Record<EntitlementFeature, boolean> => {
  const normalized = normalizePlanId(planId);
  return DEFAULT_PLAN_FEATURES[normalized];
};

export const getDefaultPlanLimits = (
  planId?: Entitlement["planId"] | string
): EntitlementLimits => {
  const normalized = normalizePlanId(planId);
  return DEFAULT_PLAN_LIMITS[normalized];
};

export const resolveEffectivePlanFeatures = (
  planId: Entitlement["planId"],
  rawFeatures?: Partial<Record<EntitlementFeature, boolean>> | null
): Record<EntitlementFeature, boolean> => ({
  ...getDefaultPlanFeatures(planId),
  ...(rawFeatures ?? {}),
});

export const resolveEffectivePlanLimits = (
  planId: Entitlement["planId"],
  rawLimits?: Partial<EntitlementLimits> | null
): EntitlementLimits => {
  const defaults = getDefaultPlanLimits(planId);
  if (!rawLimits) return defaults;

  const coalesceLimit = (key: keyof EntitlementLimits) => {
    const rawValue = rawLimits[key];
    if (typeof rawValue !== "number") {
      return defaults[key];
    }
    if (rawValue <= 0 && defaults[key] > 0 && !["free", "basic"].includes(planId)) {
      return defaults[key];
    }
    if (rawValue < defaults[key] && !["free", "basic"].includes(planId)) {
      return defaults[key];
    }
    return rawValue;
  };

  return {
    maxUsers: coalesceLimit("maxUsers"),
    maxSites: coalesceLimit("maxSites"),
    maxDepartments: coalesceLimit("maxDepartments"),
    maxAssets: coalesceLimit("maxAssets"),
    maxActivePreventives: coalesceLimit("maxActivePreventives"),
    maxOpenTickets: coalesceLimit("maxOpenTickets"),
    maxOpenTasks: coalesceLimit("maxOpenTasks"),
    attachmentsMonthlyMB: coalesceLimit("attachmentsMonthlyMB"),
    maxAttachmentMB: coalesceLimit("maxAttachmentMB"),
    maxAttachmentsPerTicket: coalesceLimit("maxAttachmentsPerTicket"),
    retentionDays: coalesceLimit("retentionDays"),
  };
};

export type EntitlementWithFeatures = Entitlement & {
  features?: Record<EntitlementFeature, boolean>;
};

export type EntitlementCreateKind =
  | "assets"
  | "sites"
  | "departments"
  | "users"
  | "preventives";

export const getOrgEntitlement = async (
  db: Firestore,
  orgId: string
): Promise<EntitlementWithFeatures | null> => {
  if (!orgId) return null;

  const orgRef = doc(db, "organizations", orgId);
  const orgSnap = await getDoc(orgRef);
  if (!orgSnap.exists()) return null;

  const orgData = orgSnap.data() as Organization;
  const entitlement = orgData?.entitlement ?? null;
  if (!entitlement) return null;

  const normalizedPlanId = normalizePlanId(entitlement.planId);
  const planCatalogRef = doc(db, "planCatalog", normalizedPlanId);
  const planCatalogSnap = await getDoc(planCatalogRef);
  const planCatalogData = planCatalogSnap.exists()
    ? (planCatalogSnap.data() as PlanCatalogEntry)
    : null;

  return {
    ...entitlement,
    planId: normalizedPlanId,
    limits: resolveEffectivePlanLimits(normalizedPlanId, planCatalogData?.limits ?? entitlement.limits),
    features: resolveEffectivePlanFeatures(normalizedPlanId, planCatalogData?.features ?? null),
  };
};

export const isFeatureEnabled = (
  entitlement: EntitlementWithFeatures | null | undefined,
  feature: EntitlementFeature
): boolean => {
  if (!entitlement) return false;
  return entitlement.features?.[feature] === true;
};

export const canCreate = (
  kind: EntitlementCreateKind,
  usage: EntitlementUsage | null | undefined,
  limits: EntitlementLimits | null | undefined
): boolean => {
  if (!usage || !limits) return false;

  const withinLimit = (current: number, max: number) =>
    Number.isFinite(max) ? current < max : true;

  switch (kind) {
    case "sites":
      return withinLimit(usage.sitesCount, limits.maxSites);
    case "assets":
      return withinLimit(usage.assetsCount, limits.maxAssets);
    case "departments":
      return withinLimit(usage.departmentsCount, limits.maxDepartments);
    case "users":
      return withinLimit(usage.usersCount, limits.maxUsers);
    case "preventives":
      return withinLimit(
        usage.activePreventivesCount,
        limits.maxActivePreventives
      );
    default: {
      const _exhaustive: never = kind;
      return _exhaustive;
    }
  }
};
