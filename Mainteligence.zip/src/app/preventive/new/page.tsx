'use client';

import { useEffect, useState } from 'react';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { doc, getDoc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

import { AppShell } from '@/components/app-shell';
import { Icons } from '@/components/icons';
import { Button } from '@/components/ui/button';
import {
  PreventiveTemplateForm,
  type PreventiveTemplateFormValues,
} from '@/components/preventive-template-form';
import { useCollection, useDoc, useFirebaseApp, useFirestore, useUser } from '@/lib/firebase';
import type { Asset, Department, Organization, PreventiveTemplate, Site } from '@/lib/firebase/models';
import { isFeatureEnabled, normalizePlanId, resolveEffectivePlanFeatures } from '@/lib/entitlements';
import { orgCollectionPath, orgPreventiveTemplatesPath } from '@/lib/organization';

const normalizeOptional = (value?: string) =>
  value && value !== '__none__' ? value : undefined;

const parseChecklistText = (text?: string) => {
  const raw = String(text ?? '').split(/\r?\n/);
  const out: { label: string; required: boolean; order: number }[] = [];
  let order = 0;
  for (const line of raw) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const optional = trimmed.startsWith('?');
    const label = trimmed.replace(/^\?\s*/, '').trim();
    if (!label) continue;
    out.push({ label, required: !optional, order: order++ });
  }
  return out;
};

export default function NewPreventiveTemplatePage() {
  const router = useRouter();
  const app = useFirebaseApp();
  const firestore = useFirestore();
  const { user, loading: userLoading, organizationId } = useUser();
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [planFeatures, setPlanFeatures] = useState<Record<string, boolean> | null>(null);

  useEffect(() => {
    if (!userLoading && !user) {
      router.push('/login');
    }
  }, [router, user, userLoading]);

  const { data: sites } = useCollection<Site>(
    organizationId ? orgCollectionPath(organizationId, 'sites') : null
  );
  const { data: departments } = useCollection<Department>(
    organizationId ? orgCollectionPath(organizationId, 'departments') : null
  );
  const { data: assets } = useCollection<Asset>(
    organizationId ? orgCollectionPath(organizationId, 'assets') : null
  );
  const { data: organization } = useDoc<Organization>(
    organizationId ? `organizations/${organizationId}` : null
  );
  const { data: templates } = useCollection<PreventiveTemplate>(
    organizationId ? orgPreventiveTemplatesPath(organizationId) : null
  );

  useEffect(() => {
    if (!firestore || !organization?.entitlement?.planId) {
      setPlanFeatures(null);
      return;
    }

    let cancelled = false;

    const normalizedPlanId = normalizePlanId(organization.entitlement.planId);
    getDoc(doc(firestore, 'planCatalog', normalizedPlanId))
      .then((snap) => {
        if (cancelled) {
          return;
        }

        const features =
          (snap.exists() ? (snap.data()?.features as Record<string, boolean>) : null) ?? null;
        setPlanFeatures(features);
      })
      .catch(() => {
        if (cancelled) {
          return;
        }
        setPlanFeatures(null);
      });

    return () => {
      cancelled = true;
    };
  }, [firestore, organization?.entitlement?.planId]);

  const entitlement = organization?.entitlement ?? null;
  const preventivesAllowed = entitlement
    ? isFeatureEnabled({
        ...entitlement,
        features: resolveEffectivePlanFeatures(normalizePlanId(entitlement.planId), planFeatures),
      }, 'PREVENTIVES')
    : false;
  const preventivesPaused = Boolean(organization?.preventivesPausedByEntitlement);
  const isDemoOrganization =
    organization?.type === 'demo' ||
    organization?.subscriptionPlan === 'trial' ||
    (organizationId ? organizationId.startsWith('demo-') : false);
  const demoTemplateLimitReached = isDemoOrganization && templates.length >= 5;
  const preventivesBlockedByPlan = !preventivesAllowed && !isDemoOrganization;
  const preventivesBlocked = preventivesBlockedByPlan || demoTemplateLimitReached;

  if (userLoading || !user) {
    return (
      <div className="flex h-screen w-screen items-center justify-center">
        <Icons.spinner className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleSubmit = async (values: PreventiveTemplateFormValues) => {
    if (!app) {
      setErrorMessage('No se pudo inicializar Firebase App.');
      return;
    }

    if (!firestore) {
      setErrorMessage('No se pudo inicializar la base de datos.');
      return;
    }

    if (!organizationId) {
      setErrorMessage('No encontramos un organizationId válido.');
      return;
    }

    setSubmitting(true);
    setErrorMessage(null);

    try {
      const fn = httpsCallable(getFunctions(app), 'createPreventiveTemplate');

      await fn({
        organizationId,
        name: values.name.trim(),
        description: values.description?.trim() || null,
        status: values.status,
        automatic: values.automatic,
        checklist: parseChecklistText(values.checklistText),
        schedule: {
          type: values.scheduleType,
          timezone:
            typeof Intl !== 'undefined'
              ? Intl.DateTimeFormat().resolvedOptions().timeZone
              : undefined,
          timeOfDay: values.timeOfDay?.trim() || undefined,
          daysOfWeek: values.daysOfWeek?.length ? values.daysOfWeek : undefined,
          dayOfMonth:
            typeof values.dayOfMonth === 'number' && !Number.isNaN(values.dayOfMonth)
              ? values.dayOfMonth
              : undefined,
          date: values.date ? values.date : undefined,
        },
        priority: values.priority,
        siteId: normalizeOptional(values.siteId),
        departmentId: normalizeOptional(values.departmentId),
        assetId: normalizeOptional(values.assetId),
      });

      router.push('/preventive');
    } catch (error) {
      console.error('Error al crear la plantilla preventiva', error);

      const errorCode =
        typeof error === 'object' && error !== null && 'code' in error
          ? String(error.code ?? '')
          : '';
      const backendMessage =
        typeof error === 'object' && error !== null && 'message' in error
          ? String(error.message ?? '').trim()
          : '';
      const normalizedMessage = backendMessage.toLowerCase();

      const cleanBackendMessage = backendMessage.replace(/^[a-z-]+:\s*/i, '');

      if (normalizedMessage.includes('hasta 5 plantillas')) {
        setErrorMessage('La demo permite hasta 5 plantillas preventivas. Cambia tu plan para crear más.');
        return;
      }

      if (normalizedMessage.includes('plan no incluye preventivos')) {
        setErrorMessage('Tu plan no incluye preventivos. Actualiza tu plan para crear plantillas.');
        return;
      }

      if (errorCode.includes('permission-denied')) {
        setErrorMessage(cleanBackendMessage || 'No tienes permisos para crear plantillas preventivas.');
        return;
      }

      if (errorCode.includes('invalid-argument') || errorCode.includes('failed-precondition') || errorCode.includes('not-found')) {
        setErrorMessage(cleanBackendMessage || 'No se pudo crear la plantilla preventiva. Revisa los datos e inténtalo de nuevo.');
        return;
      }

      if (errorCode.includes('internal')) {
        setErrorMessage('Error interno al crear la plantilla preventiva. Inténtalo de nuevo en unos minutos.');
        return;
      }

      setErrorMessage(
        cleanBackendMessage ||
          (error instanceof Error && error.message
            ? error.message
            : 'No se pudo crear la plantilla. Inténtalo de nuevo.')
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppShell
      title="Nueva plantilla preventiva"
      description="Define la frecuencia y alcance de mantenimiento preventivo."
    >
      {preventivesBlocked || preventivesPaused ? (
        <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-6 text-sm text-amber-100">
          <p>
            {demoTemplateLimitReached
              ? 'La demo permite hasta 5 plantillas preventivas. Cambia tu plan para crear más.'
              : preventivesBlocked
                ? 'Tu plan actual no incluye preventivos. Actualiza tu plan para habilitar esta función.'
                : 'Los preventivos están pausados por limitaciones del plan actual.'}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild>
              <Link href="/plans">Ver planes</Link>
            </Button>
            <Button variant="outline" onClick={() => router.push('/preventive')}>
              Volver
            </Button>
          </div>
        </div>
      ) : (
        <div className="rounded-lg border border-white/80 bg-card p-6 shadow-sm">
          <PreventiveTemplateForm
            onSubmit={handleSubmit}
            submitting={submitting || userLoading}
            errorMessage={errorMessage}
            onCancel={() => router.push('/preventive')}
            sites={sites}
            departments={departments}
            assets={assets}
          />
        </div>
      )}
    </AppShell>
  );
}
