"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Icons } from "@/components/icons";
import { AppShell } from "@/components/app-shell";
import {
  useAuth,
  useCollection,
  useDoc,
  useFirestore,
  useUser,
} from "@/lib/firebase";
import type { MaintenanceTask } from "@/types/maintenance-task";
import type { Department, OrganizationMember } from "@/lib/firebase/models";
import { createTask, updateTask } from "@/lib/firestore-tasks";
import { useToast } from "@/hooks/use-toast";
import { buildRbacUser, getTaskPermissions, normalizeRole } from "@/lib/rbac";
import { useScopedTasks } from "@/lib/scoped-collections";
import { normalizeTaskStatus, taskStatusLabel } from "@/lib/status";
import { orgCollectionPath, orgDocPath } from "@/lib/organization";

const statusCopy: Record<string, string> = {
  open: taskStatusLabel("open"),
  in_progress: taskStatusLabel("in_progress"),
  done: taskStatusLabel("done"),
  canceled: taskStatusLabel("canceled"),
  validated: taskStatusLabel("validated"),
  blocked: taskStatusLabel("blocked"),
};

const priorityCopy: Record<MaintenanceTask["priority"], string> = {
  alta: "Alta",
  media: "Media",
  baja: "Baja",
};

type DateFilter = "todas" | "hoy" | "semana" | "mes";

type TaskWithId = MaintenanceTask & { id: string };

export default function ClosedTasksPage() {
  const router = useRouter();
  const firestore = useFirestore();
  const auth = useAuth();
  const { user, profile, role, loading: userLoading, organizationId } = useUser();
  const { toast } = useToast();

  const normalizedRole = normalizeRole(role ?? profile?.role);
  const isSuperAdmin = normalizedRole === "super_admin";
  const isAdmin = normalizedRole === "admin" || isSuperAdmin;

  const { data: currentMember } = useDoc<OrganizationMember>(
    user && organizationId ? orgDocPath(organizationId, "members", user.uid) : null
  );
  const rbacUser = buildRbacUser({
    role,
    organizationId,
    member: currentMember,
    profile: profile ?? null,
  });

  const { data: tasks, loading } = useScopedTasks({
    organizationId,
    rbacUser,
    uid: user?.uid ?? null,
  });
  const { data: departments } = useCollection<Department>(
    organizationId ? orgCollectionPath(organizationId, "departments") : null
  );
  const canReadMembers =
    normalizedRole &&
    ["super_admin", "admin", "mantenimiento", "jefe_departamento", "jefe_ubicacion", "auditor"].includes(
      normalizedRole
    );
  const { data: users } = useCollection<OrganizationMember>(
    canReadMembers && organizationId ? orgCollectionPath(organizationId, "members") : null
  );

  // Nota: para tareas cerradas, la lectura del documento propio de miembro (members/{uid})
  // es suficiente para construir el RBAC del usuario.

  const [dateFilter, setDateFilter] = useState<DateFilter>("todas");
  const [departmentFilter, setDepartmentFilter] = useState("todas");
  const [userFilter, setUserFilter] = useState("todas");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (!userLoading && !user) {
      router.push("/login");
    }
  }, [router, user, userLoading]);

  const filteredTasks = useMemo(() => {
    const now = new Date();
    const dateLimits: Record<DateFilter, Date | null> = {
      todas: null,
      hoy: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
      semana: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
      mes: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000),
    };

    const visibleTasks = rbacUser
      ? tasks.filter((task) => getTaskPermissions(task, rbacUser, user?.uid ?? null).canView)
      : tasks;

    const doneTasks = visibleTasks.filter(
      (task) => normalizeTaskStatus(task.status) === "done"
    );

    return [...doneTasks]
      .filter((task) => {
        const createdAtDate = task.createdAt?.toDate?.() ?? null;
        if (dateLimits[dateFilter] && createdAtDate) {
          return createdAtDate >= (dateLimits[dateFilter] as Date);
        }
        return true;
      })
      .filter(
        (task) =>
          departmentFilter === "todas" ||
          (task.targetDepartmentId ?? task.originDepartmentId ?? task.departmentId) ===
            departmentFilter
      )
      .filter((task) => {
        if (userFilter === "todas") return true;
        return task.createdBy === userFilter || task.assignedTo === userFilter;
      })
      .filter((task) => {
        if (!searchQuery) return true;
        return task.title.toLowerCase().includes(searchQuery.toLowerCase());
      })
      .sort((a, b) => {
        const aCreatedAt = a.createdAt?.toMillis?.() ?? 0;
        const bCreatedAt = b.createdAt?.toMillis?.() ?? 0;
        return bCreatedAt - aCreatedAt;
      });
  }, [dateFilter, departmentFilter, searchQuery, tasks, user, userFilter, rbacUser]);

  const handleReopen = async (task: TaskWithId) => {
    if (!firestore || !auth || !user || !isAdmin) return;

    try {
      const targetOrgId = organizationId ?? task.organizationId;
      if (!targetOrgId) return;
      await updateTask(firestore, auth, targetOrgId, task.id, {
        status: "open",
      });
      toast({ title: "Tarea reabierta", description: "Se movió la tarea a abiertas." });
    } catch (error) {
      console.error("No se pudo reabrir la tarea", error);
      toast({
        title: "Error al reabrir",
        description: "Inténtalo de nuevo en unos segundos.",
        variant: "destructive",
      });
    }
  };

  const handleDuplicate = async (task: TaskWithId) => {
    const targetOrgId = organizationId ?? task.organizationId;

    if (!firestore || !auth || !user || !isAdmin || !targetOrgId) return;

    try {
      await createTask(firestore, auth, {
        title: task.title,
        description: task.description,
        status: "open",
        priority: task.priority,
        dueDate: task.dueDate ?? null,
        assignedTo: task.assignedTo ?? "",
        originDepartmentId: task.originDepartmentId ?? task.departmentId,
        targetDepartmentId: task.targetDepartmentId ?? task.departmentId,
        locationId: task.locationId ?? null,
        category: task.category ?? "",
        reopened: false,
        organizationId: targetOrgId,
      });
      toast({ title: "Tarea duplicada", description: "Se creó una nueva tarea a partir de la cerrada." });
    } catch (error) {
      console.error("No se pudo duplicar la tarea", error);
      toast({
        title: "Error al duplicar",
        description: "Revisa tu conexión e inténtalo nuevamente.",
        variant: "destructive",
      });
    }
  };

  const isLoading = loading || userLoading;
  return (
    <AppShell
      title="Tareas cerradas"
      description="Historial de tareas completadas con filtros avanzados."
    >
      <div className="flex flex-col gap-4 rounded-lg border border-white/60 bg-sky-400/15 p-4 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <Input
            placeholder="Buscar por título"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="md:max-w-xs"
          />
          <div className="flex flex-wrap gap-3">
            <Select value={dateFilter} onValueChange={(value: DateFilter) => setDateFilter(value)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Fecha" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todo el historial</SelectItem>
                <SelectItem value="hoy">Hoy</SelectItem>
                <SelectItem value="semana">Últimos 7 días</SelectItem>
                <SelectItem value="mes">Últimos 30 días</SelectItem>
              </SelectContent>
            </Select>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Departamento" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todos los departamentos</SelectItem>
                {departments.map((department) => (
                  <SelectItem key={department.id} value={department.id}>
                    {department.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={userFilter} onValueChange={setUserFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Usuario" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todos los usuarios</SelectItem>
                {users.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.displayName || item.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {isLoading && (
            <div className="flex h-24 items-center justify-center gap-2 rounded-lg border border-white/20 bg-background text-muted-foreground sm:col-span-2 xl:col-span-3">
              <Icons.spinner className="h-4 w-4 animate-spin" /> Cargando tareas...
            </div>
          )}
          {!isLoading && filteredTasks.length === 0 && (
            <div className="flex h-24 items-center justify-center rounded-lg border border-white/20 bg-background text-muted-foreground sm:col-span-2 xl:col-span-3">
              No se encontraron tareas cerradas con esos filtros.
            </div>
          )}
          {!isLoading &&
            filteredTasks.map((task) => {
              const departmentLabel =
                departments.find(
                  (dept) =>
                    dept.id ===
                    (task.targetDepartmentId ?? task.originDepartmentId ?? task.departmentId ?? "")
                )?.name || "Sin departamento";
              const createdAtLabel = task.createdAt?.toDate
                ? format(task.createdAt.toDate(), "dd/MM/yyyy", { locale: es })
                : "Sin fecha";
              return (
                <div
                  key={task.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => router.push(`/tasks/${task.id}`)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      router.push(`/tasks/${task.id}`);
                    }
                  }}
                  className="block rounded-lg border border-white/20 bg-background p-4 text-left shadow-sm transition hover:border-primary/40 hover:bg-muted/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-base font-semibold text-foreground">{task.title}</p>
                        <Badge variant="outline">{statusCopy[normalizeTaskStatus(task.status)]}</Badge>
                        {task.reopened && (
                          <Badge variant="outline" className="text-xs">
                            Reabierta
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                        <span>Departamento: {departmentLabel}</span>
                        <span>Creada: {createdAtLabel}</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant={task.priority === "alta" ? "destructive" : "secondary"}>
                        Prioridad {priorityCopy[task.priority]}
                      </Badge>
                      {isAdmin && (
                        <div className="flex flex-wrap gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(event) => {
                              event.stopPropagation();
                              void handleReopen(task);
                            }}
                          >
                            Reabrir
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(event) => {
                              event.stopPropagation();
                              void handleDuplicate(task);
                            }}
                          >
                            Duplicar
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </AppShell>
  );
}
